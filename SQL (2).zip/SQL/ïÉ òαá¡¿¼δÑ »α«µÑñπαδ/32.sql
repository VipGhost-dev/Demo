DECLARE @q AS Int
EXEC Count_Assistent_Itogo 2000, '%����%', @q output select @q