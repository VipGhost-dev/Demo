CREATE PROC select_zavkaf @k CHAR(10)
AS SELECT * FROM Kafedra WHERE Fio_zavkaf=@k