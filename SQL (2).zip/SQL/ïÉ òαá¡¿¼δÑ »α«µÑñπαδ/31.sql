CREATE PROC Count_Assistent_Itogo @Sum_salary Int, @Title Char(15), @Itogo Int OUTPUT
AS SELECT @Itogo=count(DOLGNOST) from TEACHER
WHERE SALARY<=@Sum_salary AND DOLGNOST Like @Title