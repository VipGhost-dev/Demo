DECLARE @return_status int
EXECUTE @return_status=checkname 15 SELECT 'Return Status'=@return_status