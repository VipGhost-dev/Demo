CREATE PROC Count_Assistent_Salary_Title @Sum_salary as INT, @Title as CHAR(15)
AS SELECT count(NAME_TEACHER) FROM TEACHER
WHERE SALARY>=@Sum_salary AND DOLGNOST LIKE @Title