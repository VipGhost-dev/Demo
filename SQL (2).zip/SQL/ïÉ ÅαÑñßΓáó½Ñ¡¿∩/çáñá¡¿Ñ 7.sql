DECLARE @mytable TABLE(idkaf INT, idfak INT, myname CHAR(50), fio char(50), nomerkom INT, nomerkorp INT, tel CHAR (50))
INSERT @mytable SELECT * FROM Kafedra 
DECLARE @a INT, @b INT
SELECT @a=COUNT(*) FROM Kafedra 
WHILE @a<10
begin
SET @a=@a+1
INSERT INTO @mytable(idkaf, myname)
values(@a, '��� ����������')
end;
SELECT * FROM @mytable