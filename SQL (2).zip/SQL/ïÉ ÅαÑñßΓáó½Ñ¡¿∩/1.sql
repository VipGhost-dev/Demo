DECLARE @a INT, @b numeric(10,2)
DECLARE @str CHAR(20)
SET @a=20
SET @b=(@a+@a)/15
SELECT @b