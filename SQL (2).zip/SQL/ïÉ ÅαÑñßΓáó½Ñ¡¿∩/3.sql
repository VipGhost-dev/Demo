DECLARE @str CHAR(30)
SELECT @str=Sutname FROM Student SELECT @str