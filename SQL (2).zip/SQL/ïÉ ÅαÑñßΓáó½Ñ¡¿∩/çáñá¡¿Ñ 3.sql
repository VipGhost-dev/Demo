DECLARE @itog FLOAT 
SET @itog=(SELECT COUNT(*) FROM Kafedra)
PRINT @itog