GO
CREATE PROC ProductSummary AS
BEGIN
SELECT ProductName AS Product, Manufacturer, Price
FROM Product
END;