UPDATE TEACHER
SET Salary = Salary + Salary * 0.12, Rise = Rise + Rise * 0.08;