WITH OrdersInfo AS
(
SELECT ProductId,
SUM(ProductCount) AS TotalCount,
SUM(ProductCount*Price) AS TotalSum
FROM Orders
GROUP BY ProductId
)
SELECT * FROM OrdersInfo