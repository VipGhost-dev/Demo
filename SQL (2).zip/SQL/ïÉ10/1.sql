CREATE TABLE #ProductSummary (ProdID INT IDENTITY, ProdName NVARCHAR(20), Price MONEY)
INSERT INTO #ProductSummary
VALUES ('Nokia 8', 18000),
('iPhone 8', 56000)
SELECT * FROM #ProductSummary