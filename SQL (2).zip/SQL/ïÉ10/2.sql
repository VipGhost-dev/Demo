SELECT ProductId,
SUM(ProductCount) AS TotalCount,
SUM(ProductCount*Price) AS TotalSum
INTO #OrdersSummary
FROM Orders
GROUP BY ProductId

SELECT Products.ProductName, #OrdersSummary.TotalCount, #OrdersSummary.TotalSum
FROM Products
JOIN #OrdersSummary ON Products.Id = #OrdersSummary.ProductId