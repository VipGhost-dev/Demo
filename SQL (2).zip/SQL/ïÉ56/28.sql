SELECT FACULTET.Name_fakulteta, FACULTET.kod_fakulteta, KAFEDRA. Kod_faculteta, KAFEDRA.Name_Kafedru
FROM FACULTET, KAFEDRA;