SELECT Name_Kafedru, student.[GROUP] FROM	KAFEDRA, STUDENT
WHERE KAFEDRA.kod_kafedru = STUDENT.kod_kafedru;