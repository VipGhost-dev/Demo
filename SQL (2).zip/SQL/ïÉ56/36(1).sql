SELECT f.*, k.FIO_ZAVKAF, t.*
FROM	FACULTET f, KAFEDRA k, TEACHER t
WHERE	f.kod_fakulteta = k.Kod_faculteta AND k.Kod_kafedru = t.Kod_kafedru;