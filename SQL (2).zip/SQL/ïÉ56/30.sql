SELECT FACULTET.Name_fakulteta, KAFEDRA.Name_Kafedru FROM	FACULTET, KAFEDRA
WHERE FACULTET.kod_fakulteta = KAFEDRA.Kod_faculteta;