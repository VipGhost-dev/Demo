CREATE VIEW report (Name_student, Fam_student, City)
AS SELECT STUDENT.SUTNAME,
STUDENT.SUTFNAME,
CITY = cast ( City as char(5))+ CASE WHEN LEN (CITY) > 5 THEN '...' END
FROM STUDENT INNER JOIN Kafedra ON STUDENT.KOD_KAFEDRU=Kafedra.Kod_kafedru