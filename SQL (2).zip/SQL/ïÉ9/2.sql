INSERT INTO ProductView (Product, Manufacturer, Price)
VALUES ('Nokia 8', 'HDC Global', 18000)