DELETE FROM ProductView
WHERE Product='Nokia 8'