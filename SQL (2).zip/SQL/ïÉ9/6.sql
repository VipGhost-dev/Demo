DECLARE @ABrends TABLE (ProductId INT, ProductName NVARCHAR(20)) 
INSERT INTO @ABrends
VALUES(1, 'iPhone 8'),
(2, 'Samsumg Galaxy S8')
SELECT * FROM @ABrends