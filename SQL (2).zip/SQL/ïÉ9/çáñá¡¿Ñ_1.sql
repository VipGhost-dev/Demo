CREATE VIEW Facultet_pr
AS SELECT kod_fakulteta, Name_fakulteta, Fio_Dekana
FROM Facultet