CREATE VIEW ProductView
AS SELECT ProductName AS Product, Manufacturer, Price
From Products