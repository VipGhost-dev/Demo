UPDATE ProductView 
SET Price=1500 WHERE Product='Nokia 8'