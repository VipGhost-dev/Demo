﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    class Class1
    {
        static void Main()
        {
            Console.Write("Добро пожаловать!\nВведите имя пользователя:");
            string name = Console.ReadLine();
            Console.Write("Введите Ваш возраст:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите Ваш пароль:");
            string password = Console.ReadLine();
            Console.Write($"Проверьте введенные данные!\nИмя:{name}  Возраст:{age}  Пароль:{password}");
            Console.ReadKey();
        }
    }
}
